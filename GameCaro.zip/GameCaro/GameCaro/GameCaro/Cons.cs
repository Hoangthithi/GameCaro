﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameCaro
{
    public class Cons
    {
        public static int CHESS_WIDTH = 50;
        public static int CHESS_HEIGHT = 50;

        public static int CHESS_BOARD_WIDTH = 24;
        public static int CHESS_BOARD_HEIGHT = 18;

        public static int COOL_DOWN_STEP = 100;
        public static int COOL_DOWN_TIME = 10000;
        public static int COOL_DOWN_INTERVAL = 100; 
    }
}
